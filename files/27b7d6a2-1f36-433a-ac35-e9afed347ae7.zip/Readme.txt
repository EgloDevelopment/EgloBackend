============
TI DooM v1.3
============

for the TI-83(+)
written in BASIC
made by Guiral Ferrieu
brainwave4ever@hotmail.com
(C) Brain Software

1)Introduction
--------------
This is a game totally in 3D based on DooM. This game is 20k large so
you have to reset your calculator before installing it because it takes
all the RAM of the TI-83(+). You can look at 4 screenshots in this zip
file!

2)Menu
------
NEW GAME   => You start the game from the first level.
LOAD GAME  => You start the game from the last level where you saved
              but you keep the weapons you had before. You can save
              after each level.
CHOOSE MAP => You can choose the level you want to play but you start
              with only 50 bullets for the pistol.
QUIT GAME  => You exit the game.

3)Controls
----------
[Arrows]		move
[Up] (long pressure)	run
[2nd]			shoot
[ALPHA]			open/push
[MODE]			map
[Y=]			pistol
[WINDOW]		shotgun
[ZOOM]			chaingun
[CLEAR]			quit


4)Weapons
---------
You can find 3 different weapons:
-pistol (5 bullets)
-shotgun (4 shells)
-chaingun (10 bullets)
You can have a maximum of:
-100 bullets for the pistol
-50 shells for the shotgun
-200 bullets for the chaingun

5)Enemies
---------
There are 2 different enemies with their own animation:
-imp
-shotgun guy
The shotgun guy let his shotgun when he is killed.

6)Keycards/Doors
----------------
You can find 3 different keycards:
-red
-blue
-yellow
They are useful to open the red/blue/yellow doors.

7)Health
--------
You can found 2 different bonuses to increase your health:
-stimpack (10%)
-medikit (25%)
You can have a maximum of 100% of health.

8)Levels
--------
There are 10 levels in this game.

9)Contact
---------
This is the first game I put on the web so I NEED your comments about
it and/or about bugs you could find.
Questions are also welcomed.
Here is my e-mail address:
brainwave4ever@hotmail.com
You can write in French or in English. Please tell me if you play on a
TI-83 or a TI-83 Plus or a TI-83 Plus Silver Edition.